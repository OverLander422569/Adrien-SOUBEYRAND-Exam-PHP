cahier des charges

l'idée est de créer un CRUD qui respecte le design pattern MVC pour gérer des entités : "contact".

- importer le fichier

Techniques et savoirs à illustrer dans votre code:
● Structure de base du PHP (for if/else ...)
● Tableau PHP
● Classe et Objet
● Utilisation d'une librairie dans votre code source
● Utilisation d'une librairie via Composer
● Opération CRUD
● Mise en place d'un Modèle-Vue-Controller
● Mise en place d'un Front-Controller
● Le programme fonctionne au lancement
● Théorie : En commentaire dans votre fichier README.md expliquer l'intérêt
du Design Pattern: Service Container / Injection de dépendance
● Bonus: illustrer le concept et la notion de NameSpace
● Bonus : Utilisation de la librairie DI

